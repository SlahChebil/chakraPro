export const steps = [
  {
    title: 'Step 1',
    description: 'Description',
  },
  {
    title: 'Step 2',
    description: 'Description',
  },
  {
    title: 'Step 3',
    description: 'Description',
  },
  {
    title: 'Step 4',
    description: 'Description',
  },
  {
    title: 'Step 5',
    description: 'Description',
  },
]
